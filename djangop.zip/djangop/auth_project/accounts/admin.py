from django.contrib import admin
from .models import Salle

admin.site.register(Salle)
