from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import CustomUser, Reservation, Salle
from django.core.exceptions import ValidationError
from django.utils import timezone

class CustomUserCreationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    
    class Meta:
        model = CustomUser
        fields = ('username', 'email', 'password1', 'password2')

class ReservationForm(forms.ModelForm):
    class Meta:
        model = Reservation
        fields = ['salle', 'date_debut', 'date_fin', 'motif']
        widgets = {
            'date_debut': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'date_fin': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'motif': forms.Textarea(attrs={'rows': 3}),
        }

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        
    def clean(self):
        cleaned_data = super().clean()
        date_debut = cleaned_data.get('date_debut')
        date_fin = cleaned_data.get('date_fin')
        salle = cleaned_data.get('salle')
        
        if date_debut and date_fin:
            if date_debut < timezone.now():
                raise ValidationError("La date de réservation ne peut pas être dans le passé")
            
            if date_fin <= date_debut:
                raise ValidationError("La date de fin doit être après la date de début")
            
            # Vérification de disponibilité
            if Reservation.objects.filter(
                salle=salle,
                date_debut__lt=date_fin,
                date_fin__gt=date_debut
            ).exists():
                raise ValidationError("La salle n'est pas disponible pour cette plage horaire")
        
        return cleaned_data

    def save(self, commit=True):
        instance = super().save(commit=False)
        instance.demandeur = self.user
        if commit:
            instance.save()
        return instance