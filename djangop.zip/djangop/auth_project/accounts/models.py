from django.db import models
from django.contrib.auth.models import AbstractUser
from django.core.mail import send_mail
from django.conf import settings
from django.utils import timezone

class CustomUser(AbstractUser):
    age = models.PositiveIntegerField(null=True, blank=True)
    phone = models.CharField(max_length=20, blank=True)

class Salle(models.Model):
    nom = models.CharField(max_length=100)
    capacité = models.IntegerField()
    équipements = models.TextField()

    def __str__(self):
        return self.nom

class Reservation(models.Model):
    STATUT_CHOICES = [
        ('attente', 'En attente'),
        ('confirmé', 'Confirmé'),
        ('refusé', 'Refusé'),
    ]

    demandeur = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    salle = models.ForeignKey(Salle, on_delete=models.CASCADE)
    date_debut = models.DateTimeField()
    date_fin = models.DateTimeField()
    motif = models.TextField()
    statut = models.CharField(max_length=10, choices=STATUT_CHOICES, default='attente')
    date_demande = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.salle.nom} - {self.demandeur.username} ({self.date_debut})"