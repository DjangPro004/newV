from django.urls import path
from .views import home, signup, reserver_salle, liste_reservations
from django.contrib.auth.views import LoginView, LogoutView

urlpatterns = [
    path('', home, name='home'),
    path('signup/', signup, name='signup'),
    path('login/', LoginView.as_view(template_name='registration/login.html'), name='login'),
    path('logout/', LogoutView.as_view(), name='logout'),
    
    # Réservations
    path('reserver/', reserver_salle, name='reserver_salle'),
    path('mes-reservations/', liste_reservations, name='liste_reservations'),
]