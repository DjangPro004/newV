from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import CustomUserCreationForm, ReservationForm
from .models import Reservation

def home(request):
    return render(request, 'home.html')

def signup(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
    else:
        form = CustomUserCreationForm()
    return render(request, 'registration/signup.html', {'form': form})

@login_required
def reserver_salle(request):
    if request.method == 'POST':
        form = ReservationForm(request.POST, user=request.user)
        if form.is_valid():
            reservation = form.save()
            
            # Vérification automatique
            if reservation.salle.capacité > 10:  # Exemple simple
                reservation.statut = 'confirmé'
                messages.success(request, "Réservation confirmée immédiatement!")
            else:
                messages.info(request, "Votre réservation est en attente de validation")
            
            reservation.save()
            return redirect('liste_reservations')
    else:
        form = ReservationForm(user=request.user)
    
    return render(request, 'reservation/reserver.html', {'form': form})

@login_required
def liste_reservations(request):
    reservations = Reservation.objects.filter(demandeur=request.user)
    return render(request, 'reservation/liste.html', {'reservations': reservations})